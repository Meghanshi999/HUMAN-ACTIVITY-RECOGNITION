
import cv2 
  
# Function to extract frames 
def FrameCapture(path): 
      
     
    vidObj = cv2.VideoCapture(path) 
  count = 0
  
    # checks whether frames were extracted 
    success = 1
  
    while success: 
  
       
        success, image = vidObj.read() 
  
        
        cv2.imwrite("frame%d.jpg" % count, image) 
  
        count += 1

if __name__ == '__main__': 
  
    # Calling the function 
    FrameCapture("clap.avi") 